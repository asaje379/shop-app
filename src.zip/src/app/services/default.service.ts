import { AngularFirestore } from '@angular/fire/firestore';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DefaultService {

  constructor(
    private db: AngularFirestore
  ) { }

  save(dbname: string, item: any) {
    return this.db.collection(dbname).doc(item.id+'').set(item);
  }

  getAll(dbname: string) {
    return this.db.collection(dbname).valueChanges();
  }

  delete(dbname: string, id) {
    return this.db.collection(dbname).doc(id+'').delete();
  }

  filter(dbname: string, attr: string, value: string) {
    return this.db.collection(dbname, ref => ref.where(attr, '==', value)).valueChanges();
  }

  getFilteredData(dbname: string) {
    return this.db.collection(dbname, ref => ref.where('isActive', '==', true)).valueChanges();
  }
}
