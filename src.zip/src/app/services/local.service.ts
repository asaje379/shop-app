import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LocalService {

  db = [];
  subjects = [];
  users: any[] = [];
  fournisseurs: any[] = [];
  articles: any[] = [];
  colors: any[] = [];
  marks: any[] = [];
  factures: any[] = [];
  categories: any[] = [];
  tails: any[] = [];
  stocks: any[] = [];

  transaction;
  objectStore;

  dbname: string = '';
  p;

  constructor() {
    this.init();
  }

  init() {
    this.subjects['users'] = new Subject<any[]>();
    this.subjects['fournisseurs'] = new Subject<any[]>();
    this.subjects['articles'] = new Subject<any[]>();
    this.subjects['colors'] = new Subject<any[]>();
    this.subjects['marks'] = new Subject<any[]>();
    this.subjects['factures'] = new Subject<any[]>();
    this.subjects['categories'] = new Subject<any[]>();
    this.subjects['tails'] = new Subject<any[]>();
    this.subjects['stocks'] = new Subject<any[]>();
  }

  emitUsers() {
    this.subjects['users'].next(this.users.slice());
  }
  emitFournisseurs() {
    this.subjects['fournisseurs'].next(this.fournisseurs.slice());
  }
  emitArticles() {
    this.subjects['articles'].next(this.articles.slice());
  }
  emitColors() {
    this.subjects['colors'].next(this.colors.slice());
  }
  emitMarks() {
    this.subjects['marks'].next(this.marks.slice());
  }
  emitFactures() {
    this.subjects['factures'].next(this.factures.slice());
  }
  emitCategories() {
    this.subjects['categories'].next(this.categories.slice());
  }
  emitTails() {
    this.subjects['tails'].next(this.tails.slice());
  }
  emitStocks() {
    this.subjects['stocks'].next(this.stocks.slice());
  }

  createTable(dbname, fields: any[]): Promise<any> {
    return new Promise((resolve, reject) => {
      let request = window.indexedDB.open(dbname, 1);
      request.onsuccess = () => {
        this.db[dbname] = request.result;
        resolve(this.db[dbname]);
      }

      request.onupgradeneeded = (e: any) => {
        let db = e.target.result;

        let objectStore = db.createObjectStore(dbname, { keyPath: 'id', autoIncrement: true });

        for (let f of fields) {
          objectStore.createIndex(f.title, f.title, f.unique);
        }
      }
    });
  }

  save(dbname, item: any, array) {
    return new Promise((resolve, reject) => {
      let transaction = this.db[dbname].transaction([dbname], 'readwrite');
      let objectStore = transaction.objectStore(dbname);
      objectStore.put(item);
      array = [];
      this.getAll(dbname, array).then((value) => {
        console.log(value);
        this.subjects[dbname].next(value);
      });
      resolve('Saved successfully');
    })
  }

  filter(array: any[], value: string, attr: string) {
    let selected = [];
    for (let item of array) {
      if (item[value] == attr) {
        selected.push(item);
      }
    }
    return selected;
  }

  getFilteredData(array: any[]) {
    let selected = [];
    for (let item of array) {
      if (item.isActive) {
        selected.push(item);
      }
    }
    return selected;
  }

  getAll(dbname, array) {
    return new Promise((resolve) => {
      console.log(this.db);
      let transactions = [];
      transactions['categories'] = this.db['categories'] ? this.db['categories'].transaction(['categories'], 'readwrite'): null;
      transactions['tails'] = this.db['tails'] ? this.db['tails'].transaction(['tails'], 'readwrite'): null;
      transactions['marks'] = this.db['marks'] ? this.db['marks'].transaction(['marks'], 'readwrite'): null;
      transactions['colors'] = this.db['colors'] ? this.db['colors'].transaction(['colors'], 'readwrite'): null;
      transactions['users'] = this.db['users'] ? this.db['users'].transaction(['users'], 'readwrite'): null;
      transactions['fournisseurs'] = this.db['fournisseurs'] ? this.db['fournisseurs'].transaction(['fournisseurs'], 'readwrite'): null;
      transactions['articles'] = this.db['articles'] ? this.db['articles'].transaction(['articles'], 'readwrite'): null;
      transactions['factures'] = this.db['factures'] ? this.db['factures'].transaction(['factures'], 'readwrite'): null;
      transactions['stocks'] = this.db['stocks'] ? this.db['stocks'].transaction(['stocks'], 'readwrite'): null;
      let objectStore = transactions[dbname].objectStore(dbname);

      array = [];
      if (this.db) {
        let request = objectStore.openCursor();
        request.onsuccess = (e: any) => {
          let cursor = e.target.result;
          if (cursor !== null) {
            if (cursor.value.isActive)
              array.push(cursor.value);
            cursor.continue();
          }
          resolve(array);
        }
      }
    });
  }

  initDbs(dbname) {
    switch (dbname) {

      case 'users':
        // User's table creation
        this.createTable('users', [
          { title: 'username', unique: true },
          { title: 'password', unique: true },
          { title: 'createdAt', unique: true },
          { title: 'isAdmin', unique: true },
          { title: 'isActive', unique: true },
        ]).then((data) => {
          this.db['users'] = data;
          this.getAll('users', this.users).then((value) => {
            this.subjects['users'].next(value);
          });
        });
        break;

      case 'fournisseurs':
        // Sellers's table creation
        this.createTable('fournisseurs', [
          { title: 'name', unique: true },
          { title: 'tel', unique: true },
          { title: 'createdAt', unique: true },
          { title: 'lastUpdatedAt', unique: true }
        ]).then((data) => {
          this.db['fournisseurs'] = data;
          this.getAll('fournisseurs', this.fournisseurs).then((value) => {
            this.subjects['fournisseurs'].next(value);
          });
        });
        break;

      case 'articles':
        // Articles's table creation
        this.createTable('articles', [
          { title: 'category', unique: true },
          { title: 'color', unique: true },
          { title: 'lastUpdatedAt', unique: true },
          { title: 'createdAt', unique: true },
          { title: 'isAdmin', unique: true },
          { title: 'isActive', unique: true },
          { title: 'level', unique: true },
          { title: 'lib', unique: true },
          { title: 'marque', unique: true },
          { title: 'prixAchats', unique: true },
          { title: 'prixVentes', unique: true },
          { title: 'quantite', unique: true },
          { title: 'ref', unique: true },
          { title: 'taille', unique: true },
        ]).then((data) => {
          this.db['article'] = data;
          this.getAll('articles', this.articles).then((value) => {
            this.subjects['articles'].next(value);
          });
        });
        break;

      case 'colors':
        // Color's table creation
        this.createTable('colors', [
          { title: 'lastUpdatedAt', unique: true },
          { title: 'value', unique: true },
          { title: 'createdAt', unique: true },
          { title: 'isActive', unique: true },
        ]).then((data) => {
          this.db['colors'] = data;
          console.log(this.db);
          this.getAll('colors', this.colors).then((value) => {
            this.subjects['colors'].next(value);
          });
        });
        break;

      case 'categories':
        // Categories's table creation
        this.createTable('categories', [
          { title: 'lastUpdatedAt', unique: true },
          { title: 'value', unique: true },
          { title: 'createdAt', unique: true },
          { title: 'isActive', unique: true },
        ]).then((data) => {
          this.db['categories'] = data;
          this.getAll('categories', this.categories).then((value) => {
            this.subjects['categories'].next(value);
          });
        });
        break;

      case 'tails':
        // Capacities's table creation
        this.createTable('tails', [
          { title: 'lastUpdatedAt', unique: true },
          { title: 'value', unique: true },
          { title: 'createdAt', unique: true },
          { title: 'isActive', unique: true },
        ]).then((data) => {
          this.db['tails'] = data;
          this.getAll('tails', this.tails).then((value) => {
            this.subjects['tails'].next(value);
          });
        });
        break;

      case 'marks':
        // Mark's table creation
        this.createTable('marks', [
          { title: 'lastUpdatedAt', unique: true },
          { title: 'value', unique: true },
          { title: 'createdAt', unique: true },
          { title: 'isActive', unique: true },
        ]).then((data) => {
          this.db['marks'] = data;
          this.getAll('marks', this.marks).then((value) => {
            this.subjects['marks'].next(value);
          });
        });
        break;

      case 'factures':
        // Factures's table creation
        this.createTable('factures', [
          { title: 'client', unique: true },
          { title: 'tel', unique: true },
          { title: 'dateFacturation', unique: true },
          { title: 'montant', unique: true },
          { title: 'commandes', unique: true }
        ]).then((data) => {
          this.db['factures'] = data;
          this.getAll('factures', this.factures).then((value) => {
            this.subjects['factures'].next(value);
          });
        });
        break;

        case 'stocks':
        // Factures's table creation
        this.createTable('stocks', [
          { title: 'articles', unique: true },
          { title: 'createdAt', unique: true },
        ]).then((data) => {
          this.db['stocks'] = data;
          this.getAll('stocks', this.stocks).then((value) => {
            this.subjects['stocks'].next(value);
          });
        });
        break;
    }
  }
}
