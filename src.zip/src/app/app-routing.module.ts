import { StockComponent } from './components/settings/stock/stock.component';
import { BaseComponent } from './components/settings/base/base.component';
import { SigninComponent } from './components/auth/signin/signin.component';
import { InventoryComponent } from './components/inventory/inventory.component';
import { ArticleComponent } from './components/inventory/article/article.component';
import { StateComponent } from './components/settings/state/state.component';
import { ColorComponent } from './components/settings/color/color.component';
import { TypeComponent } from './components/settings/type/type.component';
import { TailComponent } from './components/settings/tail/tail.component';
import { MarkComponent } from './components/settings/mark/mark.component';
import { HomeComponent } from './components/home/home.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './components/auth/login/login.component';
import { CategoryComponent } from './components/settings/category/category.component';
import { SellingComponent } from './components/selling/selling.component';
import { FournisseurComponent } from './components/settings/fournisseur/fournisseur.component';

const routes: Routes = [
  {
    path: 'home',
    component: HomeComponent,
    children: [
      { path: 'category', component: CategoryComponent },
      { path: 'marque', component: MarkComponent },
      { path: 'taille', component: TailComponent },
      { path: 'type', component: TypeComponent },
      { path: 'color', component: ColorComponent },
      { path: 'state', component: StateComponent },
      { path: 'article', component: ArticleComponent },
      { path: 'selling', component: SellingComponent },
      { path: 'inventory', component: InventoryComponent },
      {
        path: 'params',
        component: BaseComponent,
        children: [
          { path: 'signin', component: SigninComponent },
          { path: 'stock', component: StockComponent },
          { path: 'fournisseur', component: FournisseurComponent }
        ]
      }
    ]
  },
  { path: 'login', component: LoginComponent },
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'signin', component: SigninComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
