export class Article {

    constructor(
        public id?: number,
        public ref?: string,
        public lib?: string,
        public category?: string,
        public taille?: string,
        public color?: string,
        public marque?: string,
        public state?: number,
        public level?: number,
        public type?: string,
        public createdAt?: number,
        public lastUpdatedAt?: number,
        public isActive?: boolean,
        public prixAchats?: number[],
        public prixVentes?: number[],
        public quantite?: number
    ) {
        this.quantite = this.quantite ? this.quantite : 0;
        this.ref = this.ref ? this.ref : null;
        this.lib = this.lib ? this.lib : null;
        this.category = this.category ? this.category : null;
        this.level = this.level ? this.level : null;
        this.type = this.type ? this.type : null;
        this.taille = this.taille ? this.taille : null;
        this.color = this.color ? this.color : null;
        this.marque = this.marque ? this.marque : null;
        this.state = this.state ? this.state : 10;
        this.createdAt = this.lastUpdatedAt = Date.now();
        this.isActive = true;
    }
}
