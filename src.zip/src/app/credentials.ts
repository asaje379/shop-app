export var firebaseConfig = {
    production: false,
    config: {
        apiKey: "AIzaSyDlaqCiMkTSno4Lry3ET3gXJWFpaKtR-II",
        authDomain: "soutenanceinfoviewer.firebaseapp.com",
        databaseURL: "https://soutenanceinfoviewer.firebaseio.com",
        projectId: "soutenanceinfoviewer",
        storageBucket: "soutenanceinfoviewer.appspot.com",
        messagingSenderId: "1087632440567",
        appId: "1:1087632440567:web:b2d7267b33907af1"
    }
};