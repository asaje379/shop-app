import { Router } from '@angular/router';
import { DefaultService } from './../../../services/default.service';
import { Subscription } from 'rxjs';
import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-state',
  templateUrl: './state.component.html',
  styleUrls: ['./state.component.scss']
})
export class StateComponent implements OnInit {

  @Output()
  emitState = new EventEmitter<string>();
  value: string = '';
  msg : string = 'Sélectionné : ';

  state: string = '';
  sub: Subscription;
  sub2: Subscription;
  states: { id: string, value: string }[] = [];
  mdlIsActive: boolean = false;
  statesFull = [];
  btn_text: string = 'Ajouter';
  category: any;

  constructor(private service: DefaultService, private router: Router) { }

  ngOnInit() {
    this.sub = this.service.getFilteredData('states').subscribe(
      (data: any) => {
        this.states = data;
      }
    );
    this.sub2 = this.service.getAll('states').subscribe(
      (data: any) => {
        this.statesFull = data;
      }
    );
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  onSubmit() {
    let id = this.btn_text == 'Ajouter' ? this.genId() : this.category.id;
    this.btn_text == 'Ajouter' ? this.service.save('states', { 
      id: id, 
      value: this.state, 
      isActive: true,
      createdAt: Date.now(),
      lastUpdatedAt: Date.now() 
    }) : this.service.save('states', { 
      id: id, 
      value: this.state, 
      isActive: true,
      lastUpdatedAt: Date.now() 
    });
    this.mdlIsActive = false;
    this.state = '';
  }

  applyFilter(filterValue: string) {
    let selected = [];

    if (filterValue.length != 0) {
      for (let c of this.states) {
        if (c.value.toLowerCase().indexOf(filterValue.toLowerCase()) != -1) {
          selected.push(c);
        }
      }
      this.states = selected;
    } else {
      this.sub = this.service.getAll('states').subscribe(
        (data: any) => {
          this.states = data;
        }
      );
    }
  
  }

  genId() {
    if (this.statesFull.length == 0) {
      return 1;
    } else {
      return this.statesFull[this.statesFull.length - 1].id + 1;
    }
  }

  setMdlActive() {
    this.state = '';
    this.mdlIsActive = true;
    this.btn_text = 'Ajouter';
  }

  onUpdate(c) {
    this.mdlIsActive = true;
    this.state = c.value;
    this.btn_text = 'Modifier';
    this.category = c;
  }

  onArchive(c) {
    if(confirm('Etes-vous sûr de vouloir effectuer cette opération ?')) {
      this.service.save('states', { 
        id: c.id, 
        value: c.value, 
        isActive: false,
        lastUpdatedAt: Date.now() 
      });
    }
  }

  send(c) {
    this.value = c.value;
    this.emitState.emit(this.value);
    this.msg = 'Sélectionné : ' + this.value;
    setTimeout(
      () => {
        this.value = '';
      }, 3000
    );
  }
}
