import { Router } from '@angular/router';
import { DefaultService } from './../../../services/default.service';
import { Subscription } from 'rxjs';
import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-type',
  templateUrl: './type.component.html',
  styleUrls: ['./type.component.scss']
})
export class TypeComponent implements OnInit {

  @Output()
  emitType = new EventEmitter<string>();
  value: string = '';
  msg : string = 'Sélectionné : ';

  type: string = '';
  sub: Subscription;
  sub2: Subscription;
  types: { id: string, value: string }[] = [];
  mdlIsActive: boolean = false;
  typesFull = [];
  btn_text: string = 'Ajouter';
  category: any;

  constructor(private service: DefaultService, private router: Router) { }

  ngOnInit() {
    this.sub = this.service.getFilteredData('types').subscribe(
      (data: any) => {
        this.types = data;
      }
    );
    this.sub2 = this.service.getAll('types').subscribe(
      (data: any) => {
        this.typesFull = data;
      }
    );
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  onSubmit() {
    let id = this.btn_text == 'Ajouter' ? this.genId() : this.category.id;
    this.btn_text == 'Ajouter' ? this.service.save('types', { 
      id: id, 
      value: this.type, 
      isActive: true,
      createdAt: Date.now(),
      lastUpdatedAt: Date.now() 
    }) : this.service.save('types', { 
      id: id, 
      value: this.type, 
      isActive: true,
      lastUpdatedAt: Date.now() 
    });
    this.mdlIsActive = false;
    this.type = '';
  }

  applyFilter(filterValue: string) {
    let selected = [];

    if (filterValue.length != 0) {
      for (let c of this.types) {
        if (c.value.toLowerCase().indexOf(filterValue.toLowerCase()) != -1) {
          selected.push(c);
        }
      }
      this.types = selected;
    } else {
      this.sub = this.service.getAll('types').subscribe(
        (data: any) => {
          this.types = data;
        }
      );
    }
  }

  genId() {
    if (this.typesFull.length == 0) {
      return 1;
    } else {
      return this.typesFull[this.typesFull.length - 1].id + 1;
    }
  }

  setMdlActive() {
    this.type = '';
    this.mdlIsActive = true;
    this.btn_text = 'Ajouter';
  }

  onUpdate(c) {
    this.mdlIsActive = true;
    this.type = c.value;
    this.btn_text = 'Modifier';
    this.category = c;
  }

  onArchive(c) {
    if(confirm('Etes-vous sûr de vouloir effectuer cette opération ?')) {
      this.service.save('types', { 
        id: c.id, 
        value: c.value, 
        isActive: false,
        lastUpdatedAt: Date.now() 
      });
    }
  }

  send(c) {
    this.value = c.value;
    this.emitType.emit(this.value);
    this.msg = 'Sélectionné : ' + this.value;
    setTimeout(
      () => {
        this.value = '';
      }, 3000
    );
  }
}
