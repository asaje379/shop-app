import { LocalService } from './../../services/local.service';
import { Article } from './../../models/article';
import { DefaultService } from 'src/app/services/default.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import printJS from 'print-js';

@Component({
  selector: 'app-selling',
  templateUrl: './selling.component.html',
  styleUrls: ['./selling.component.scss']
})
export class SellingComponent implements OnInit, OnDestroy {

  articles: any[] = [];
  sub: Subscription;
  subFact: Subscription;
  error: string = '';
  show = false;

  curArticle: Article = new Article();

  prix: number = 5;
  quantite: number = 1;
  facture = {
    id: null,
    client: null,
    tel: null,
    commandes: [],
    dateFacturation: Date.now(),
    montant: 0
  };
  factures: any[] = [];

  c_ref: true;
  c_cat: true;
  c_tai: true;
  c_cou: true;
  c_mar: true;

  constructor(
    private service: DefaultService, private localService: LocalService
  ) { }

  ngOnInit() {
    this.iinit();
  }

  iinit() {
    this.localService.initDbs('articles');
    this.sub = this.localService.subjects['articles'].subscribe(
      (data) => {
        this.articles = data;
      }
    );
    this.localService.initDbs('factures');
    this.subFact = this.localService.subjects['factures'].subscribe(
      (data) => {
        this.factures = data;
      }
    );
  }

  check($event) {
    if (this.quantite > this.curArticle.quantite) {
      this.error = 'Erreur : Il ne reste que ' + this.curArticle.quantite + ' ' + this.curArticle.lib + '(s) en stock !';
    } else {
      this.error = '';
    }
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
    this.subFact.unsubscribe();
  }

  select(article) {
    this.curArticle = article;
  }

  genId() {
    if (this.factures.length == 0) {
      return 1;
    } else {
      return this.factures[this.factures.length - 1].id + 1;
    }
  }

  init() {
    this.curArticle = new Article();
    this.prix = 5,
    this.quantite = 1;
  }

  next() {
    if(this.facture.commandes.length == 0)
      this.facture.id = this.genId();
    this.facture.commandes.push({
      article: this.curArticle,
      prix: this.prix,
      quantite: this.quantite
    });
    this.facture.montant += this.prix * this.quantite;
    this.init();
  }

  applyFilter($e) {
    let selected = [];
    if ($e.length != 0) {
      for (let a of this.articles) {
        if (
          a.ref.toLowerCase().indexOf($e.toLowerCase()) != -1 ||
          a.lib.toLowerCase().indexOf($e.toLowerCase()) != -1 ||
          a.type.toLowerCase().indexOf($e.toLowerCase()) != -1 ||
          a.category.toLowerCase().indexOf($e.toLowerCase()) != -1 ||
          a.marque.toLowerCase().indexOf($e.toLowerCase()) != -1 ||
          a.taille.toLowerCase().indexOf($e.toLowerCase()) != -1 ||
          a.color.toLowerCase().indexOf($e.toLowerCase()) != -1 ||
          (a.state + '').toLowerCase().indexOf($e.toLowerCase()) != -1
        ) {
          selected.push(a);
        }
      }
      this.articles = selected;
    } else {
      this.iinit();
    }
  }

  print() {
    printJS({
      printable: "facture",
      type: "html",
      css: "assets/print.css"
    });
  }

  terminate() {
    for (let a of this.facture.commandes) {
      a.article.quantite -= a.quantite;
      a.article.lastUpdatedAt = Date.now();
      this.localService.save('articles', a.article, this.localService.articles);
    }
    this.localService.save('factures', this.facture, this.localService.factures);
    this.show = true;
  }

  annuler() {
    this.init();
    this.error = '';
    this.facture = {
      id: null,
      client: null,
      tel: null,
      commandes: [],
      dateFacturation: Date.now(),
      montant: 0
    };
  }
}
