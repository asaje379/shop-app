import { LocalService } from 'src/app/services/local.service';
import { DefaultService } from './../../../services/default.service';
import { Subscription } from 'rxjs';
import { Article } from './../../../models/article';
import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-article',
  templateUrl: './article.component.html',
  styleUrls: ['./article.component.scss']
})
export class ArticleComponent implements OnInit, OnDestroy {

  categorie: string = '';
  color: string = '';
  mark: string = '';
  tail: string = '';
  ref: string = '';
  lib: string = '';
  fournisseur = '';
  show: boolean = false;
  article = new Article();
  articles: Article[] = [];
  articlesFull: Article[] = [];
  ars: any[] = [];
  sub: Subscription;
  sub2: Subscription;

  constructor(
    private service: DefaultService,
    private localService: LocalService
  ) { }

  init() {
    this.localService.initDbs('articles');
    this.sub = this.localService.subjects['articles'].subscribe(
      (data) => {
        this.articles = data;
      }
    );
  }

  ngOnInit() {
    this.localService.initDbs('articles');
    this.init();
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  showDetail() {
    this.ngOnInit();
    this.show = true;
  }

  update() {
    this.ngOnInit();
    this.show = false;
  }

  save() {
    this.localService.save('articles', {
      ref: this.ref,
      lib: this.lib,
      taille: this.tail,
      color: this.color,
      marque: this.mark,
      fournisseur: this.fournisseur,
      createdAt: Date.now(),
      lastUpdatedAt: Date.now(),
      isActive: true,
      prixAchats: [],
      prixVentes: [],
      quantite: 0
    }, this.localService.articles);
    this.ref = this.lib = '';
    this.color = '';
    this.mark = '';
    this.tail = '';
  }

  objlength(obj: any) {
    let cpt = 0;
    for (let o in obj) {
      ++cpt;
    }
    return cpt;
  }

}
