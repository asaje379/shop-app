import { LocalService } from 'src/app/services/local.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DefaultService } from './../../services/default.service';
import { Subscription } from 'rxjs';
import { Article } from './../../models/article';
import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-inventory',
  templateUrl: './inventory.component.html',
  styleUrls: ['./inventory.component.scss']
})
export class InventoryComponent implements OnInit, OnDestroy {

  articles: Article[] = [];
  stocks: any[] = [];
  subArticle: Subscription;
  subStock: Subscription;
  curArticle: Article = new Article();
  pa: number = 0;
  pv: number = 5;

  curStocks: any[] = [];
  form: FormGroup;

  active: boolean = false;

  constructor(
    private service: DefaultService,
    private localService: LocalService,
    private formBuilder: FormBuilder
  ) { }

  ngOnInit() {
    this.init();
    this.initForm();
  }

  ngOnDestroy() {
    this.subArticle.unsubscribe();
    this.subStock.unsubscribe();
  }

  init() {
    this.localService.initDbs('articles');
    this.subArticle = this.localService.subjects['articles'].subscribe(
      (data) => {
        this.articles = data;
      }
    );
    this.localService.initDbs('stocks');
    this.subStock = this.localService.subjects['stocks'].subscribe(
      (data) => {
        this.stocks = data;
      }
    );
  }

  initForm() {
    this.form = this.formBuilder.group({
      prixAchat: [0, [Validators.required, Validators.min(0)]],
      prixVente: [5, [Validators.required, Validators.min(5)]],
      quantite: [1, [Validators.required, Validators.min(1)]]
    });
  }

  selectArticle(art: any) {
    this.curArticle = art;
  }

  next() {
    const data = this.form.value;
    let st = {
      article: this.curArticle,
      prixAchat: data.prixAchat,
      prixVente: data.prixVente,
      quantite: data.quantite,
    }
    this.curStocks.push(st);
    this.initForm();
    this.curArticle = new Article();
  }

  applyFilter($e) {
    let selected = [];
    if ($e.length != 0) {
      for (let a of this.articles) {
        if (
          a.ref.toLowerCase().indexOf($e.toLowerCase()) != -1 ||
          a.lib.toLowerCase().indexOf($e.toLowerCase()) != -1 ||
          a.type.toLowerCase().indexOf($e.toLowerCase()) != -1 ||
          a.category.toLowerCase().indexOf($e.toLowerCase()) != -1 ||
          a.marque.toLowerCase().indexOf($e.toLowerCase()) != -1 ||
          a.taille.toLowerCase().indexOf($e.toLowerCase()) != -1 ||
          a.color.toLowerCase().indexOf($e.toLowerCase()) != -1 ||
          (a.state + '').toLowerCase().indexOf($e.toLowerCase()) != -1
        ) {
          selected.push(a);
        }
      }
      this.articles = selected;
    } else {
      this.init();
    }
  }

  terminate() {
    let arts = new Array();
    for (let st of this.curStocks) {
      arts.push(st.article.id);
      st.article.lastUpdatedAt = Date.now(),
        st.article.prixAchats.push(st.prixAchat);
      st.article.prixVentes.push(st.prixVente);
      st.article.quantite += st.quantite;
      this.localService.save('articles', st.article, this.localService.articles);
    }
    let st = {
      articles: arts,
      createdAt: Date.now(),
    };
    this.localService.save('stocks', st, this.localService.stocks);
    this.curStocks = [];
    this.curArticle = new Article();
    this.init();
  }

  annuler() {
    this.curStocks = [];
    this.initForm();
    this.curArticle = new Article();
  }
}
