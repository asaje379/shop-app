import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flash-error',
  templateUrl: './flash-error.component.html',
  styleUrls: ['./flash-error.component.scss']
})
export class FlashErrorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
