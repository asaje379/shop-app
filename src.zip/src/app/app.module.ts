import { HomeComponent } from './components/home/home.component';
import { SellingComponent } from './components/selling/selling.component';
import { InventoryComponent } from './components/inventory/inventory.component';
import { RouterModule } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AngularFontAwesomeModule } from 'angular-font-awesome';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PapaParseModule } from 'ngx-papaparse';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { firebaseConfig } from './credentials';
import { AngularFireModule } from '@angular/fire';
import { AngularFirestoreModule } from '@angular/fire/firestore';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TypeComponent } from './components/settings/type/type.component';
import { CategoryComponent } from './components/settings/category/category.component';
import { TailComponent } from './components/settings/tail/tail.component';
import { MarkComponent } from './components/settings/mark/mark.component';
import { FlashBoxComponent } from './components/flash-box/flash-box.component';
import { SigninComponent } from './components/auth/signin/signin.component';
import { LoginComponent } from './components/auth/login/login.component';
import { ArticleComponent } from './components/inventory/article/article.component';
import { ColorComponent } from './components/settings/color/color.component';
import { StateComponent } from './components/settings/state/state.component';
import { NgxPrintModule } from 'ngx-print';
import { BaseComponent } from './components/settings/base/base.component';
import { StockComponent } from './components/settings/stock/stock.component';
import { FlashErrorComponent } from './components/flash-error/flash-error.component';
import { FournisseurComponent } from './components/settings/fournisseur/fournisseur.component';
import { FRComponent } from './components/settings/f-r/f-r.component';

@NgModule({
  declarations: [
    AppComponent,
    TypeComponent,
    CategoryComponent,
    TailComponent,
    MarkComponent,
    FlashBoxComponent,
    SigninComponent,
    LoginComponent,
    InventoryComponent,
    SellingComponent,
    HomeComponent,
    ArticleComponent,
    ColorComponent,
    StateComponent,
    BaseComponent,
    StockComponent,
    FlashErrorComponent,
    FournisseurComponent,
    FRComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    PapaParseModule,
    BrowserAnimationsModule,
    AngularFireModule.initializeApp(firebaseConfig.config),
    AngularFirestoreModule.enablePersistence(),
    AngularFontAwesomeModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    NgxPrintModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
